var express = require('express');
var app = express();
var mysql = require('mysql');
var connection = mysql.createConnection({

  host     : 'localhost',
  user     : 'root',
  password : 'password',
  database : 'mydb'
});
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.listen(3000,function(){
    console.log('Node server running @ http://localhost:8080')
});

app.use('/style',  express.static(__dirname + '/style'));

app.use('/node_modules',  express.static(__dirname + '/node_modules'));

app.get('/', function(req, response) {
    response.sendFile('index.html',{'root': __dirname + '/templates'});
});
app.get('/try', function(req, response) {
    response.sendFile('sign_in.html',{'root': __dirname + '/templates'});
});
app.post('/sign_up', function(req, response) {
    console.log(req.body.firstname);
    console.log(req.body.lastname);
    // Add these values to your MySQL database here
    var record = {firstname: req.body.firstname, lastname: req.body.lastname};

  //connection.connect();
  connection.query('INSERT INTO username SET ?', record, function(err,res){
      if(err) throw err;
    console.log('Last record insert id:', res.insertId);
    response.redirect('/try');
    response.end();
  });
});

app.post('/sign_in', function(req,response){
	console.log(req.body.firstname);
    console.log(req.body.lastname);
    var selectString = 'SELECT COUNT(firstname) FROM USERNAME WHERE firstname = "'+req.body.firstname+'" AND lastname="'+req.body.lastname+'"';
    connection.query(selectString, function(err,results){

        console.log(results);
        var string=JSON.stringify(results);
        console.log(string);
        //this is a walkaround of checking if the email pass combination is 1 or not it will fail if wrong pass is given
        if (string === '[{"COUNT(firstname)":1}]') {
			response.redirect('/try');
	
	        }
        if (string === '[{"COUNT(firstname)":0}]')  {
        	response.redirect('/notfound');
        	
        }
    })

});
